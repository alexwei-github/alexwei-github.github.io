DawsonRomance game, by Alex Wei and Edwin Liu starring Dawson Lam.
made with Renpy

DawsonRomance.exe starts the game

Game/script.rpy opens the programming and script if you want to look at it, but you may need to download renpy in order to open the file.